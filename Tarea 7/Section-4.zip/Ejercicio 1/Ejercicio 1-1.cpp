#include <iostream>
#include "Cat.h"


using namespace std;

int main() {

	Cat cat1;

	cat1.speak();
	cat1.jump();


	return 0;
}