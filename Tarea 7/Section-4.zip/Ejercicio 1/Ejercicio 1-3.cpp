#include <iostream>

#include "Cat.h"

using namespace std;

void Cat::speak() {
	cout << "Meouwww!!!" << endl;
}

void Cat::jump() {
	cout << "Jumping to top of bookcase" << endl;
}
