#ifndef CAT_H_
#define CAT_H_

class Cat {
public:
	void speak();
	void jump();
};


#endif /* CAT_H_ */
