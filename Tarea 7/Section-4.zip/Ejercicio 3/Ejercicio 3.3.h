#ifndef CAT_H_
#define CAT_H_

class Cat {
private:
	bool happy;

public:
	void speak();
	Cat();
	~Cat();

};

#endif /* CAT_H_ */
