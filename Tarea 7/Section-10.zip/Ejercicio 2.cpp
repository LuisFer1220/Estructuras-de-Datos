#include <iostream>
#include <Cat.h>

int main() {

	caveofprogramming::saySomething();

	caveofprogramming::Cat bob;

	bob.speak();

	return 0;
}
