#include <iostream>
using namespace std;

int main() {
	char value = 127;

	cout << (int)value << endl;

	value++;

	cout << (int)value << endl;

	return 0;
}
