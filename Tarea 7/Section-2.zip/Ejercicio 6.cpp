#include <iostream>
#include <iomanip>
using namespace std;
int main() {
  bool bValue = true;
  cout << bValue << endl;
  char cValue = 'i';
  cout << cValue << endl;
  cout << "Sizeof char: " << sizeof(char) << endl;
  wchar_t wValue = 'i';
  cout << (char)wValue << endl;
  cout << "Sizeof wValue: " << sizeof(wValue) << endl;
  return 0;
}
