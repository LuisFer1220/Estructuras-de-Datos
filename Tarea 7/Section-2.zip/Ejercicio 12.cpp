#include <iostream>
using namespace std;

int main() {

	int i = 0;

	while(i < 5) {
		cout << "Hello " << i << endl;

		i++; // Increments i by 1
	}

	cout << "Programming quitting." << endl;

	return 0;
}
