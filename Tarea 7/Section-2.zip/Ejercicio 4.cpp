#include <iostream>
#include <limits>
using namespace std;
int main() {
   int value = -54656;
   cout << "Max int value: " << value  << endl;
   cout << "Min int value: " << value  << endl;
   long int lValue = 2345325345345;
   cout << lValue << endl;
  short int sValue = 23434;
  cout << sValue << endl;
  cout << "Size of int: " << sizeof(int) << endl;
  unsigned int uValue = 2342343;
  cout << uValue << endl;
  return 0;
}
