#include <iostream>
using namespace std;

int main(){
 
  int numberCats = 5;
  int numberDogs = 7;
  int numberAnimals = numberCats + numberDogs;

  cout << "Number of cats" << numberCats << endl;
  cout << "Number of dogs" << numberDogs << endl;
  cout << "Total numbers of animals: " << numberAnimals << endl;
  cout << "New dog acquired!" << numberDogs << endl;
  numberDogs = numberDogs - 1;
  cout << "New dog acquired!" << numberDogs << endl;
  return 0;
}