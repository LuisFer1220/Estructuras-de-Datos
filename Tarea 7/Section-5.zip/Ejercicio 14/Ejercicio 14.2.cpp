#include "Animals.h"



namespace jwp {

Cat::Cat() {
	// TODO Auto-generated constructor stub

}

Cat::~Cat() {
	// TODO Auto-generated destructor stub
}

void Cat::speak() {
	cout << "Sssssss!" << endl;
}

} /* namespace jwp */
