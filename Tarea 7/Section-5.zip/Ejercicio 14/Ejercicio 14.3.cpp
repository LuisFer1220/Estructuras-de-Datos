#include "Cat.h"

namespace cats {

Cat::Cat() {
	// TODO Auto-generated constructor stub

}

Cat::~Cat() {
	// TODO Auto-generated destructor stub
}

void Cat::speak() {
	cout << "Meuuowww!" << endl;
}

}

