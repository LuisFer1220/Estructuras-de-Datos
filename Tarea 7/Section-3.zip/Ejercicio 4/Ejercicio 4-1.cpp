#include <iostream>
#include "utils.h"
using namespace std;
int main() {
  doSomething();
  doSomething();
  return 0;
}
void doSomething() {
  cout << "Hello" << endl;
}
/*Otra clase*/
#ifndef UTILS_H_
#define UTILS_H_
void doSomething();
#endif /* UTILS_H_ */
