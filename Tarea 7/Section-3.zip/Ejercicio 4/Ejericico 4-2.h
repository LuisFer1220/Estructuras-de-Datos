#ifndef UTILS_H_
#define UTILS_H_

void doSomething();

#endif /* UTILS_H_ */