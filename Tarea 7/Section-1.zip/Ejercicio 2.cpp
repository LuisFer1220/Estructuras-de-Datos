#include <iostream>
using namespace std;
int main() {
  cout << "Starting program..." << flush;
  cout << "This is some text" << endl;
  cout << "Banana." << "Apple " << "Orange " << endl;
  cout << "This is somo more text" << endl;
  return 0;
}